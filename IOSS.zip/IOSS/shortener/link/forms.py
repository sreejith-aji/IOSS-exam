from django import forms

class LinkCreateForm(forms.Form):
    original_url = forms.URLField(widget=forms.URLInput(attrs={
        "class": "input", "placeholder": "https://example.com/very/long/link"
    }))
    custom_code = forms.CharField(required=False, max_length=30, widget=forms.TextInput(attrs={
        "class": "input", "placeholder": "custom-alias (optional)"
    }))

    def clean_custom_code(self):
        code = (self.cleaned_data.get("custom_code") or "").strip()
        if code and not code.replace("-", "").isalnum():
            raise forms.ValidationError("Alias must be letters, numbers and hyphens only.")
        return code
