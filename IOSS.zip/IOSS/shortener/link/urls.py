from django.urls import path
from . import views

app_name = "links"

urlpatterns = [
    path("", views.home, name="home"),
    path("analytics/", views.analytics, name="analytics"),
    path("api/shorten/", views.api_shorten, name="api_shorten"),
    path("<str:code>/", views.follow, name="follow"),
]
