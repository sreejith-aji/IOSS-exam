from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.db import IntegrityError
from .models import Link
import string, random

# Function to generate a random short code
def generate_short_code(length=6):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

# Home page view
def home(request):
    short_url = None

    if request.method == "POST":
        long_url = request.POST.get("long_url")
        if long_url:
            # Generate short code
            code = generate_short_code()
            link = Link(original_url=long_url, short_code=code)
            try:
                link.save()
            except IntegrityError:
                # In case code is not unique
                code = generate_short_code()
                link.short_code = code
                link.save()

            # Build the full short URL
            short_url = request.build_absolute_uri(f'/{link.short_code}')

    return render(request, 'link/home.html', {"short_url": short_url})

# Redirect view when short URL is visited
def redirect_url(request, code):
    link = get_object_or_404(Link, short_code=code)
    # Increment click count
    Link.objects.filter(pk=link.pk).update(clicks=link.clicks + 1)
    return redirect(link.original_url)
